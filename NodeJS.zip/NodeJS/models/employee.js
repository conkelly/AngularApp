const mongoose = require('mongoose');

var Employee = mongoose.model('Employee', {
    _id: {type: String}, //Just trying something out.
    companyname: {type: String},
    address: {type: String}, 
    email: {type: String},
    zipcode: {type: String},
    phone: {type: String},
    website: {type: String}, 
    description: {type: String} 
});

module.exports = { Employee };