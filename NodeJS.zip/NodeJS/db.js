const mongoose = require('mongoose');

// mongodb://username:password@localhost:27017/admin

mongoose.connect('mongodb://conor:conor123@localhost:27017/admin',
//{
    //useUnifiedTopology:false //,
    //useNewUrlParser: true,
    //useFindandModify: false
//},
(err) => {
    if (!err)
        console.log('MongoDB connection succeeded.');
    else
        console.log('Error in DB connection : ' + JSON.stringify(err, undefined, 2));
}
);

module.exports = mongoose;